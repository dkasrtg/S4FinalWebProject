
    <!-- container-scroller -->
    <!-- plugins:js -->
    <script src="<?= base_url("assets_admin/vendors/js/vendor.bundle.base.js") ?>"></script>
    <!-- endinject -->
    <!-- Plugin js for this page -->
    <script src="<?= base_url("assets_admin/vendors/chart.js/Chart.min.js") ?>"></script>
    <!-- End plugin js for this page -->
    <!-- inject:js -->
    <script src="<?= base_url("assets_admin/js/off-canvas.js") ?>"></script>
    <script src="<?= base_url("assets_admin/js/hoverable-collapse.js") ?>"></script>
    <script src="<?= base_url("assets_admin/js/misc.js") ?>"></script>
    <script src="<?= base_url("assets_admin/js/settings.js") ?>"></script>
    <script src="<?= base_url("assets_admin/js/todolist.js") ?>"></script>
    <!-- endinject -->
    <!-- Custom js for this page -->
    <script src="<?= base_url("assets_admin/js/chart.js") ?>"></script>
    <!-- End custom js for this page -->